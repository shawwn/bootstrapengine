// carbon for 9
data 'carb' (0) {
	$"0000"                                               /* .. */
};

// the plist resource should only be included in the application
// since it contains the bundle information and should not be duplicated
