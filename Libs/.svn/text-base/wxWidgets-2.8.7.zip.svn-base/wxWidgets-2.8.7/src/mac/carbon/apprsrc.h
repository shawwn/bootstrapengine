#define	kMacSTRWrongMachine 1 
#define	kMacSTRSmallSize 2 
#define	kMacSTRNoMemory 3 
#define	kMacSTROldSystem 4 
#define	kMacSTRGenericAbout 5 
#define	kMacSTRNoPre8Yet 6 
