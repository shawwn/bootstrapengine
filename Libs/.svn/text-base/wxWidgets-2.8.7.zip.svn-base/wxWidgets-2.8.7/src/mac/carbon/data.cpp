/////////////////////////////////////////////////////////////////////////////
// Name:        mac/data.cpp
// Purpose:     Various global Mac-specific data
// Author:      Stefan Csomor
// Modified by:
// Created:     1998-01-01
// RCS-ID:      $Id: data.cpp 34965 2005-07-28 22:08:31Z VZ $
// Copyright:   (c) Stefan Csomor
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"
