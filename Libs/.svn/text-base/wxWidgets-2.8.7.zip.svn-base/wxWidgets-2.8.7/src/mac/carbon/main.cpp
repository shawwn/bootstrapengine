/////////////////////////////////////////////////////////////////////////////
// Name:        main.cpp
// Purpose:     Entry point
// Author:      Stefan Csomor
// Modified by:
// Created:     1998-01-01
// RCS-ID:      $Id: main.cpp 27408 2004-05-23 20:53:33Z JS $
// Copyright:   (c) Stefan Csomor
// Licence:       wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// We don't put main() in the library any more. GD.
