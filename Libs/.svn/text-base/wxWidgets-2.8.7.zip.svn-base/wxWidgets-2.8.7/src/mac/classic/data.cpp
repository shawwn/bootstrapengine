/////////////////////////////////////////////////////////////////////////////
// Name:        src/mac/classic/data.cpp
// Purpose:     Various global Mac-specific data
// Author:      Stefan Csomor
// Modified by:
// Created:     1998-01-01
// RCS-ID:      $Id: data.cpp 38939 2006-04-27 12:47:14Z ABX $
// Copyright:   (c) Stefan Csomor
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#include "wx/wxprec.h"

#ifndef WX_PRECOMP
    #include "wx/event.h"
#endif
