/////////////////////////////////////////////////////////////////////////////
// Name:        main.cpp
// Purpose:     Entry point
// Author:      Julian Smart
// Modified by:
// Created:     17/09/98
// RCS-ID:      $Id: main.cpp 27408 2004-05-23 20:53:33Z JS $
// Copyright:   (c) Julian Smart
// Licence:   	wxWindows licence
/////////////////////////////////////////////////////////////////////////////


// We don't put main() in the library any more. RR.

