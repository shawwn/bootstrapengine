/////////////////////////////////////////////////////////////////////////////
// Name:        gtk/clipbrd.cpp
// Purpose:
// Author:      Robert Roebling
// Id:          $Id: clipbrd.cpp 35650 2005-09-23 12:56:45Z MR $
// Copyright:   (c) 1998 Robert Roebling
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

#include "wx/clipbrd.h"

#if wxUSE_CLIPBOARD

// FIXME_MGL

IMPLEMENT_DYNAMIC_CLASS(wxClipboard,wxObject)

#endif
  // wxUSE_CLIPBOARD

